<?php

class siteLangesPluginSettingsAction extends waViewAction
{

}