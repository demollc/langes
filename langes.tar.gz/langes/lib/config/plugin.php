<?php

return array(
    'name' => "L10N: Spanish",
    'img' => 'img/langes.png',
    'version' => '1.0',
    'vendor' => '991739',
    'custom_settings' => true,
);
